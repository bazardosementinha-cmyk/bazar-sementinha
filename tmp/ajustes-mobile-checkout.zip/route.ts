import { NextResponse } from "next/server";
import { supabaseService } from "@/lib/supabase/service";
import { buildTrackingRelativeUrl, normalizeWhatsApp } from "@/lib/order-links";
import { buildOrderCreatedEmail, type MailOrderItem } from "@/lib/order-notifications";
import { sendMail } from "@/lib/mail";
import { getAdminEmailCopyTo, getEmailNotificationsEnabled } from "@/lib/email-config";
import { buildOrderReminderRows } from "@/lib/order-reminders";

type PaymentPlan = "pix_now" | "card_pickup_deposit";

type ItemRow = {
  id: string;
  short_id: string;
  title: string;
  price: number;
  status: string;
};

type CustomerRow = {
  id: string;
  email: string | null;
  whatsapp: string | null;
  created_at?: string;
};

type BodyCustomer = {
  name?: unknown;
  whatsapp?: unknown;
  email?: unknown;
  instagram?: unknown;
  opt_in_marketing?: unknown;
};

type Body = {
  cart_short_ids?: unknown;
  cart_ids?: unknown;
  customer?: unknown;
  payment_plan?: unknown;
};

const PIX_KEY = "58.392.598/0001-91";
const PIX_FAVORED = "Templo de Umbanda Caboclo Sete Flexa";
const PICKUP_LOCATION = "TUCXA2";

function getErrorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  return typeof err === "string" ? err : "Erro inesperado";
}

function asString(value: unknown): string | null {
  return typeof value === "string" ? value : null;
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((x) => typeof x === "string") as string[];
}

function asBoolean(value: unknown): boolean {
  return value === true;
}

function normalizeEmail(raw: string): string {
  return raw.trim().toLowerCase();
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(value));
}

function makeCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "ORD-";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function pickPaymentPlan(value: unknown): PaymentPlan {
  const s = asString(value);
  if (s === "pix_now" || s === "card_pickup_deposit") return s;
  return "pix_now";
}

function addBusinessDays(referenceDate: Date, businessDays: number) {
  const date = new Date(referenceDate.getTime());
  let added = 0;

  while (added < businessDays) {
    date.setDate(date.getDate() + 1);
    const day = date.getDay();
    if (day !== 0 && day !== 6) added++;
  }

  return date;
}

function computeDeadlines(plan: PaymentPlan, referenceDate: Date) {
  const now = referenceDate;
  const hours24 = 24 * 60 * 60 * 1000;

  if (plan === "card_pickup_deposit") {
    const pickupDeadline = addBusinessDays(now, 10);
    return {
      expiresAt: pickupDeadline,
      pickupDeadlineAt: pickupDeadline,
      depositAmount: 1,
      depositRequired: true,
    };
  }

  const expiresAt = new Date(now.getTime() + hours24);
  return {
    expiresAt,
    pickupDeadlineAt: null as Date | null,
    depositAmount: null as number | null,
    depositRequired: false,
  };
}

function getPublicSiteUrl(): string {
  const raw =
    process.env.NEXT_PUBLIC_SITE_URL ||
    process.env.APP_BASE_URL ||
    process.env.VERCEL_PROJECT_PRODUCTION_URL ||
    "";

  if (!raw) return "";
  if (raw.startsWith("http://") || raw.startsWith("https://")) return raw.replace(/\/+$/, "");
  return `https://${raw.replace(/\/+$/, "")}`;
}

function buildAbsoluteTrackingUrl(relativeUrl: string): string {
  const base = getPublicSiteUrl();
  if (!base) return relativeUrl;
  return `${base}${relativeUrl.startsWith("/") ? relativeUrl : `/${relativeUrl}`}`;
}

function appendTrackingLink(text: string, html: string | undefined, trackingUrl: string) {
  const safeUrl = buildAbsoluteTrackingUrl(trackingUrl);

  const textWithLink =
    `${text}\n\n` +
    `Acompanhe seu pedido aqui:\n${safeUrl}\n`;

  const htmlWithLink = html
    ? `${html}<p style="margin-top:16px">Acompanhe seu pedido aqui:<br /><a href="${safeUrl}">${safeUrl}</a></p>`
    : undefined;

  return {
    text: textWithLink,
    html: htmlWithLink,
  };
}

async function findExistingCustomer(
  supabase: ReturnType<typeof supabaseService>,
  email: string,
  whatsapp: string
) {
  const { data: byEmail, error: byEmailErr } = await supabase
    .from("customers")
    .select("id,email,whatsapp,created_at")
    .ilike("email", email)
    .order("created_at", { ascending: false })
    .limit(1);

  if (byEmailErr) throw byEmailErr;
  const emailMatch = ((byEmail ?? []) as CustomerRow[])[0];
  if (emailMatch?.id) return emailMatch;

  const { data: byWhatsapp, error: byWhatsappErr } = await supabase
    .from("customers")
    .select("id,email,whatsapp,created_at")
    .order("created_at", { ascending: false })
    .limit(20);

  if (byWhatsappErr) throw byWhatsappErr;

  return ((byWhatsapp ?? []) as CustomerRow[]).find(
    (row) => normalizeWhatsApp(row.whatsapp || "") === whatsapp
  ) ?? null;
}

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const supabase = supabaseService();

    const raw = (await req.json().catch(() => null)) as Body | null;
    if (!raw || typeof raw !== "object") {
      return NextResponse.json({ error: "Payload inválido." }, { status: 400 });
    }

    const cartShortIds = Array.from(
      new Set(
        [...asStringArray(raw.cart_short_ids), ...asStringArray(raw.cart_ids)]
          .map((x) => x.trim())
          .filter(Boolean)
      )
    );

    if (cartShortIds.length === 0) {
      return NextResponse.json({ error: "Carrinho vazio." }, { status: 400 });
    }

    const customerRaw = raw.customer as BodyCustomer | undefined;
    const name = asString(customerRaw?.name)?.trim() ?? "";
    const whatsappRaw = asString(customerRaw?.whatsapp)?.trim() ?? "";
    const emailRaw = asString(customerRaw?.email)?.trim() ?? "";
    const email = normalizeEmail(emailRaw);
    const instagram = asString(customerRaw?.instagram)?.trim() || null;
    const optInMarketing = asBoolean(customerRaw?.opt_in_marketing);

    if (!name) {
      return NextResponse.json({ error: "Nome é obrigatório." }, { status: 400 });
    }
    if (!whatsappRaw) {
      return NextResponse.json({ error: "WhatsApp é obrigatório." }, { status: 400 });
    }
    if (!email) {
      return NextResponse.json({ error: "E-mail é obrigatório." }, { status: 400 });
    }
    if (!isValidEmail(email)) {
      return NextResponse.json({ error: "Informe um e-mail válido." }, { status: 400 });
    }

    const whatsapp = normalizeWhatsApp(whatsappRaw);
    if (whatsapp.length < 12) {
      return NextResponse.json({ error: "WhatsApp inválido." }, { status: 400 });
    }

    const plan = pickPaymentPlan(raw.payment_plan);
    const createdAt = new Date();
    const { expiresAt, pickupDeadlineAt, depositAmount, depositRequired } = computeDeadlines(plan, createdAt);

    const { data: items, error: itemsErr } = await supabase
      .from("items")
      .select("id, short_id, title, price, status")
      .in("short_id", cartShortIds);

    if (itemsErr) {
      return NextResponse.json({ error: getErrorMessage(itemsErr) }, { status: 500 });
    }

    const rows = (items ?? []) as ItemRow[];
    if (rows.length === 0) {
      return NextResponse.json({ error: "Nenhum item encontrado no carrinho." }, { status: 400 });
    }

    const available = rows.filter((it) => it.status === "available");
    if (available.length === 0) {
      return NextResponse.json({ error: "Nenhum item disponível no carrinho." }, { status: 400 });
    }

    const total = available.reduce((acc, it) => acc + (Number(it.price) || 0), 0);

    let existingCustomer: CustomerRow | null = null;
    try {
      existingCustomer = await findExistingCustomer(supabase, email, whatsapp);
    } catch (findErr) {
      return NextResponse.json({ error: getErrorMessage(findErr) }, { status: 500 });
    }

    let customerId: string;

    if (existingCustomer?.id) {
      customerId = existingCustomer.id;

      const { error: custUpdErr } = await supabase
        .from("customers")
        .update({
          name,
          email,
          whatsapp,
          instagram,
          opt_in_marketing: optInMarketing,
        })
        .eq("id", customerId);

      if (custUpdErr) {
        return NextResponse.json({ error: getErrorMessage(custUpdErr) }, { status: 500 });
      }
    } else {
      const { data: createdCustomer, error: custInsErr } = await supabase
        .from("customers")
        .insert({
          name,
          whatsapp,
          email,
          instagram,
          opt_in_marketing: optInMarketing,
        })
        .select("id")
        .single();

      if (custInsErr || !createdCustomer?.id) {
        return NextResponse.json({ error: getErrorMessage(custInsErr) }, { status: 500 });
      }

      customerId = createdCustomer.id as string;
    }

    const code = makeCode();
    const trackingUrl = buildTrackingRelativeUrl(code, whatsapp);

    const { data: order, error: orderErr } = await supabase
      .from("orders")
      .insert({
        code,
        customer_id: customerId,
        customer_name: name,
        customer_email: email,
        customer_whatsapp: whatsapp,
        customer_instagram: instagram,
        status: "reserved",
        total,
        pix_key: PIX_KEY,
        pickup_location: PICKUP_LOCATION,
        created_at: createdAt.toISOString(),
        expires_at: expiresAt.toISOString(),
        payment_plan: plan,
        pickup_deadline_at: pickupDeadlineAt ? pickupDeadlineAt.toISOString() : null,
        deposit_amount: depositAmount,
        deposit_required: depositRequired,
        deposit_paid: false,
      })
      .select(
        "id, code, status, total, payment_plan, deposit_amount, deposit_required, expires_at, pickup_deadline_at"
      )
      .single();

    if (orderErr || !order?.id) {
      return NextResponse.json({ error: getErrorMessage(orderErr) }, { status: 500 });
    }

    const orderItemsPayload = available.map((it) => ({
      order_id: order.id,
      item_id: it.id,
      item_short_id: it.short_id,
      item_title: it.title,
      price: it.price,
    }));

    const { error: oiErr } = await supabase.from("order_items").insert(orderItemsPayload);
    if (oiErr) {
      await supabase.from("orders").delete().eq("id", order.id);
      return NextResponse.json({ error: getErrorMessage(oiErr) }, { status: 500 });
    }

    const reminderRows = [
      ...buildOrderReminderRows(order.id as string, createdAt, plan),
      {
        order_id: order.id as string,
        kind: "cancel_24h",
        due_at: expiresAt.toISOString(),
      },
    ];
    if (reminderRows.length > 0) {
      const { error: remindersErr } = await supabase.from("order_reminders").insert(reminderRows);
      if (remindersErr) {
        await supabase.from("orders").delete().eq("id", order.id);
        return NextResponse.json({ error: getErrorMessage(remindersErr) }, { status: 500 });
      }
    }

    const { data: updatedItems, error: updErr } = await supabase
      .from("items")
      .update({ status: "reserved" })
      .in(
        "id",
        available.map((it) => it.id)
      )
      .eq("status", "available")
      .select("id");

    if (updErr) {
      await supabase
        .from("orders")
        .update({ status: "cancelled", cancelled_at: new Date().toISOString() })
        .eq("id", order.id);

      return NextResponse.json({ error: getErrorMessage(updErr) }, { status: 500 });
    }

    const updatedCount = Array.isArray(updatedItems) ? updatedItems.length : 0;
    if (updatedCount !== available.length) {
      await supabase
        .from("orders")
        .update({ status: "cancelled", cancelled_at: new Date().toISOString() })
        .eq("id", order.id);

      return NextResponse.json(
        { error: "Um ou mais itens ficaram indisponíveis durante o fechamento. Tente novamente." },
        { status: 409 }
      );
    }

    const mailItems: MailOrderItem[] = available.map((it) => ({
      item_short_id: it.short_id,
      item_title: it.title,
      price: it.price,
    }));

    const createdMail = buildOrderCreatedEmail(
      {
        code,
        customer_name: name,
        customer_email: email,
        customer_whatsapp: whatsapp,
        total,
        pix_key: PIX_KEY,
        pickup_location: PICKUP_LOCATION,
        expires_at: expiresAt.toISOString(),
        pickup_deadline_at: pickupDeadlineAt ? pickupDeadlineAt.toISOString() : null,
      },
      mailItems
    );

    const mailBody = appendTrackingLink(createdMail.text, createdMail.html, trackingUrl);

    let emailNotification: "sent" | "disabled" | "failed" = "disabled";
    if (getEmailNotificationsEnabled()) {
      const mailResult = await sendMail({
        to: email,
        cc: createdMail.cc || getAdminEmailCopyTo(),
        subject: createdMail.subject,
        text: mailBody.text,
        html: mailBody.html,
      });

      if (!mailResult.ok) {
        emailNotification = "failed";
        console.error("[checkout/create] Falha ao enviar e-mail do pedido", {
          orderCode: code,
          to: email,
          error: mailResult.error,
          code: mailResult.code,
          responseCode: mailResult.responseCode,
          command: mailResult.command,
        });
      } else {
        emailNotification = "sent";
        console.info("[checkout/create] E-mail do pedido enviado", {
          orderCode: code,
          to: email,
          cc: createdMail.cc || getAdminEmailCopyTo(),
          messageId: mailResult.messageId,
          response: mailResult.response,
        });
      }
    } else {
      console.info("[checkout/create] EMAIL_NOTIFICATIONS_ENABLED=false. E-mail do pedido não enviado.", {
        orderCode: code,
      });
    }

    return NextResponse.json({
      ok: true,
      order: {
        id: order.id as string,
        code: order.code as string,
        status: order.status as string,
        total: Number(order.total) || total,
        payment_plan: plan,
        deposit_required: Boolean(order.deposit_required ?? depositRequired),
        deposit_amount: (order.deposit_amount as number | null) ?? depositAmount,
        expires_at: (order.expires_at as string | null) ?? null,
        pickup_deadline_at:
          (order.pickup_deadline_at as string | null) ??
          (pickupDeadlineAt ? pickupDeadlineAt.toISOString() : null),
        items: available.map((it) => ({
          short_id: it.short_id,
          title: it.title,
          price: it.price,
        })),
      },
      pix: { key: PIX_KEY, favored: PIX_FAVORED },
      tracking: {
        url: trackingUrl,
      },
      notifications: {
        email: emailNotification,
      },
    });
  } catch (err) {
    return NextResponse.json({ error: getErrorMessage(err) }, { status: 500 });
  }
}