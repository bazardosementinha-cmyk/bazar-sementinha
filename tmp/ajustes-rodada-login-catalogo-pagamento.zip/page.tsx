"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import AdminNavPills from "@/components/AdminNavPills";
import ContextHelp from "@/components/ContextHelp";
import { ADMIN_HELP_TOPICS } from "@/lib/admin-help";
import { formatBRL, statusLabel, type ItemStatus } from "@/lib/utils";

type ReservationLock = {
  locked: boolean;
  order_id: string | null;
  order_code: string | null;
  order_status: string | null;
  payment_status: string | null;
  payment_proof_uploaded_at: string | null;
  paid_at: string | null;
  deadline_at: string | null;
  payment_plan: string | null;
  reason: string | null;
};

type ItemRow = {
  id: string;
  short_id: string;
  title: string;
  category: string;
  condition: string;
  price: number;
  price_from: number | null;
  status: ItemStatus;
  created_at: string;
  location_box?: string | null;
  label_template?: string | null;
  is_fragile?: boolean | null;
  is_demo?: boolean | null;
  demo_group?: string | null;
  demo_sort?: number | null;
  visibility?: string | null;
  review_status?: string | null;
  source?: string | null;
  reservation_lock?: ReservationLock;
};

const tabs: Array<{ key: ItemStatus | "all" | "demo"; label: string }> = [
  { key: "all", label: "Todos" },
  { key: "demo", label: "Demo" },
  { key: "review", label: "Em revisão" },
  { key: "available", label: "Disponível" },
  { key: "reserved", label: "Reservado" },
  { key: "sold", label: "Vendido" },
];

function getErrorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  return "Erro";
}

function pillClass(active: boolean) {
  return active
    ? "rounded-full border border-slate-900 bg-slate-900 px-3 py-1 text-sm font-semibold text-white"
    : "rounded-full border bg-white px-3 py-1 text-sm font-semibold hover:bg-slate-50";
}

function formatDateTime(value: string | null | undefined) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

function reservationLockText(lock?: ReservationLock) {
  if (!lock?.locked) return null;

  if (lock.reason === "paid") return `Pedido ${lock.order_code ?? "ativo"} pago — manter reservado até entrega`;
  if (lock.reason === "proof_submitted") return `Pedido ${lock.order_code ?? "ativo"} com comprovante enviado — aguardar conferência`;
  if (lock.reason === "delivered") return `Pedido ${lock.order_code ?? "ativo"} entregue — item deve virar vendido`;

  const deadline = formatDateTime(lock.deadline_at);
  return deadline
    ? `Pedido ${lock.order_code ?? "ativo"} protegido até ${deadline}`
    : `Pedido ${lock.order_code ?? "ativo"} com reserva ativa`;
}

function reservationOrderHref(lock?: ReservationLock) {
  if (!lock?.locked || !lock.order_id) return null;
  return `/admin/pedidos/${lock.order_id}`;
}

function isDemoItem(item: ItemRow) {
  return (
    item.is_demo === true ||
    item.visibility === "admin_demo" ||
    item.review_status === "demo" ||
    item.source === "demo_catalog" ||
    /^D(RP|CA|AC|CS|BR|AR|OT)\d{2}$/i.test(item.short_id)
  );
}

export default function AdminItensPage() {
  const [items, setItems] = useState<ItemRow[]>([]);
  const [tab, setTab] = useState<(typeof tabs)[number]["key"]>("review");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setError(null);
    const resp = await fetch("/api/admin/items");
    const data = await resp.json();
    if (!resp.ok) throw new Error(data?.error || "Falha ao carregar itens");
    setItems(Array.isArray(data?.items) ? (data.items as ItemRow[]) : []);
  }

  useEffect(() => {
    load().catch((e) => setError(getErrorMessage(e)));
  }, []);

  const filtered = useMemo(() => {
    if (tab === "demo") return items.filter(isDemoItem);

    const realItems = items.filter((it) => !isDemoItem(it));
    if (tab === "all") return realItems;

    return realItems.filter((it) => it.status === tab);
  }, [items, tab]);

  async function setStatus(short_id: string, status: ItemStatus) {
    setBusyId(short_id);
    setError(null);

    try {
      let payload: Record<string, unknown> = { short_id, status };

      if (status === "sold") {
        const input = window.prompt(
          "Preço final (opcional). Ex.: 55,00. Deixe em branco para manter o preço anunciado.",
          ""
        );
        if (input && input.trim()) payload = { ...payload, sold_price_final: input.trim() };
      }

      const resp = await fetch("/api/admin/status", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.error || "Falha ao atualizar status");

      await load();
    } catch (e: unknown) {
      setError(getErrorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  async function onDelete(short_id: string) {
    if (!confirm(`Excluir o item #${short_id}? (somente rascunhos)`)) return;
    setBusyId(short_id);
    setError(null);
    try {
      const resp = await fetch("/api/admin/delete-item", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ short_id }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.error || "Falha ao excluir");
      await load();
    } catch (e: unknown) {
      setError(getErrorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  function ActionLinks({ it }: { it: ItemRow }) {
    return (
      <div className="flex flex-wrap gap-2">
        <Link className="rounded-lg border px-2 py-1 hover:bg-slate-50" href={`/admin/ver/${it.short_id}`}>
          Ver
        </Link>
        <Link className="rounded-lg border px-2 py-1 hover:bg-slate-50" href={`/admin/editar/${it.short_id}`}>
          Editar
        </Link>
        {!isDemoItem(it) ? (
          <Link className="rounded-lg border px-2 py-1 hover:bg-slate-50" href={`/i/${it.short_id}`} target="_blank">
            Público
          </Link>
        ) : null}
        <Link className="rounded-lg border px-2 py-1 hover:bg-slate-50" href={`/admin/qr/${it.short_id}`} target="_blank">
          QR
        </Link>
        {it.status === "review" ? (
          <button
            disabled={busyId === it.short_id}
            className="rounded-lg border border-red-300 px-2 py-1 text-red-700 hover:bg-red-50 disabled:opacity-60"
            onClick={() => onDelete(it.short_id)}
            type="button"
          >
            Excluir
          </button>
        ) : null}
      </div>
    );
  }

  function ActionStatusButtons({ it }: { it: ItemRow }) {
    const lockText = reservationLockText(it.reservation_lock);
    const isLockedForAvailable = it.reservation_lock?.locked === true;

    if (it.status === "sold" || isDemoItem(it)) {
      return null;
    }

    return (
      <div className="flex flex-wrap gap-2">
        <button
          disabled={busyId === it.short_id || isLockedForAvailable}
          title={isLockedForAvailable ? (lockText ?? "Item com reserva ativa.") : undefined}
          className="rounded-lg bg-emerald-600 px-2 py-1 text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
          onClick={() => setStatus(it.short_id, "available")}
          type="button"
        >
          Disponível
        </button>

        {it.status !== "reserved" && !isLockedForAvailable ? (
          <button
            disabled={busyId === it.short_id}
            className="rounded-lg bg-amber-600 px-2 py-1 text-white hover:bg-amber-700 disabled:opacity-60"
            onClick={() => setStatus(it.short_id, "reserved")}
            type="button"
          >
            Reservar
          </button>
        ) : null}

        <button
          disabled={busyId === it.short_id}
          className="rounded-lg bg-slate-700 px-2 py-1 text-white hover:bg-slate-800 disabled:opacity-60"
          onClick={() => setStatus(it.short_id, "sold")}
          type="button"
        >
          Vendido
        </button>
      </div>
    );
  }

  function StatusInfo({ it }: { it: ItemRow }) {
    const lockText = reservationLockText(it.reservation_lock);
    const orderHref = reservationOrderHref(it.reservation_lock);

    return (
      <div>
        <div>{statusLabel(it.status)}</div>
        {lockText ? <div className="mt-1 text-xs font-medium text-amber-700">{lockText}</div> : null}
        {orderHref ? (
          <Link href={orderHref} className="mt-1 inline-flex rounded-lg border bg-white px-2 py-1 text-xs font-semibold hover:bg-slate-50">
            Ver pedido
          </Link>
        ) : null}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <AdminNavPills />

      <p className="mt-2 text-slate-600">Gerencie status (Disponível / Reservado / Vendido). Itens demo ficam separados na aba Demo para não confundir com rascunhos reais.</p>

      <ContextHelp topic={ADMIN_HELP_TOPICS.itens} className="mt-4" />

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Link href="/admin/importar" className={pillClass(false)}>
          Criar
        </Link>
        <Link href="/admin/etiquetas/lote" className={pillClass(false)}>
          Imprimir etiquetas
        </Link>

        {tabs.map((t) => (
          <button key={t.key} className={pillClass(tab === t.key)} onClick={() => setTab(t.key)} type="button">
            {t.label}
          </button>
        ))}
      </div>

      {error ? <div className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</div> : null}

      <div className="mt-4 grid gap-3 md:hidden">
        {filtered.map((it) => (
          <div key={it.id} className="rounded-2xl border bg-white p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-mono text-xs text-slate-500">#{it.short_id}</div>
                <div className="font-semibold">{it.title}</div>
                <div className="text-xs text-slate-500">{it.condition}</div>
                <div className="mt-1 text-xs text-slate-500">
                  {it.location_box ? `Local: ${it.location_box}` : "Sem local informado"}
                  {it.label_template ? ` • Etiqueta ${it.label_template}` : ""}
                  {it.is_fragile ? " • Frágil" : ""}
                  {isDemoItem(it) ? " • DEMO" : ""}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500">{it.category}</div>
                <div className="font-semibold">{formatBRL(Number(it.price))}</div>
                {it.price_from ? <div className="text-xs text-slate-500 line-through">{formatBRL(Number(it.price_from))}</div> : null}
                <div className="mt-1 text-xs font-semibold text-slate-700">
                  <StatusInfo it={it} />
                </div>
              </div>
            </div>

            <div className="mt-3 space-y-2">
              <ActionLinks it={it} />
              <ActionStatusButtons it={it} />
            </div>
          </div>
        ))}

        {!filtered.length ? (
          <div className="rounded-2xl border bg-white p-6 text-center text-sm text-slate-500">Nenhum item neste filtro.</div>
        ) : null}
      </div>

      <div className="mt-4 hidden overflow-x-auto rounded-2xl border bg-white md:block">
        <table className="min-w-[980px] w-full text-sm">
          <thead className="bg-slate-50 text-left">
            <tr>
              <th className="px-3 py-2">ID</th>
              <th className="px-3 py-2">Item</th>
              <th className="px-3 py-2">Categoria</th>
              <th className="px-3 py-2">Preço</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((it) => (
              <tr key={it.id} className="border-t">
                <td className="px-3 py-2 font-mono">#{it.short_id}</td>
                <td className="px-3 py-2">
                  <div className="font-medium">{it.title}</div>
                  <div className="text-xs text-slate-500">{it.condition}</div>
                  <div className="text-xs text-slate-500">
                    {it.location_box ? `Local: ${it.location_box}` : "Sem local informado"}
                    {it.label_template ? ` • Etiqueta ${it.label_template}` : ""}
                    {it.is_fragile ? " • Frágil" : ""}
                  {isDemoItem(it) ? " • DEMO" : ""}
                  </div>
                </td>
                <td className="px-3 py-2">{it.category}</td>
                <td className="px-3 py-2">
                  <div className="font-semibold">{formatBRL(Number(it.price))}</div>
                  {it.price_from ? <div className="text-xs text-slate-500 line-through">{formatBRL(Number(it.price_from))}</div> : null}
                </td>
                <td className="px-3 py-2">
                  <StatusInfo it={it} />
                </td>
                <td className="px-3 py-2">
                  <div className="flex flex-wrap gap-2">
                    <ActionLinks it={it} />
                    <ActionStatusButtons it={it} />
                  </div>
                </td>
              </tr>
            ))}

            {!filtered.length ? (
              <tr>
                <td className="px-3 py-6 text-center text-slate-500" colSpan={6}>
                  Nenhum item neste filtro.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}